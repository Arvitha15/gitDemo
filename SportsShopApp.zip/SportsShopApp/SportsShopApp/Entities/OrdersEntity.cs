﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsShopApp.Entities
{
    public class OrdersEntity
    {
        public OrdersEntity()
        {
            Items = new HashSet<ItemsEntity>();
        }

        public int OrderNumber { get; set; }
        public DateTime? OrderDate { get; set; }
        public string PaymentMode { get; set; }
        public string CustomerName { get; set; }

        public CustomerEntity CustomerNameNavigation { get; set; }
        public ICollection<ItemsEntity> Items { get; set; }
    }
}
