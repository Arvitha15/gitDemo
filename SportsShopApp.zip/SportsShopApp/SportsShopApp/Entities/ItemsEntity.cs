﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsShopApp.Entities
{
    public class ItemsEntity
    {
        public int ItemNumber { get; set; }
        public string ItemName { get; set; }
        public double? ItemValue { get; set; }
        public int? OrderNumber { get; set; }

        public OrdersEntity OrderNumberNavigation { get; set; }
    }
}
