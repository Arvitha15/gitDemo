﻿using SportsShopApp.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SportsShopApp.repositories
{
    public interface IOrderRepository
    {
        Task<List<OrdersEntity>> SearchAllOrders();
        Task<OrdersEntity> SearchOrderByCustomerName(string custName);

        Task<OrdersEntity> SearchOrderByOrderNum(int orderNum);
        Task<int> CreateOrder(OrdersEntity ordersEntity);
        Task UpdateOrder(int orderNum, OrdersEntity ordersEntity);
    }
}