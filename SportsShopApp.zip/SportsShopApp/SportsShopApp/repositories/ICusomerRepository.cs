﻿using SportsShopApp.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SportsShopApp.repositories
{
    public interface ICusomerRepository
    {
        Task<List<CustomerEntity>> SearchAllCustomers();
        Task<int> CreateCustomer(CustomerEntity customerEntity);
        Task UpdateCusomer(int CustNum, CustomerEntity customerEntity);

        Task DeleteCustomer(int CustNo);
    }
}