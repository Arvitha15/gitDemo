﻿using Microsoft.EntityFrameworkCore;
using SportsShopApp.Entities;
using SportsShopApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsShopApp.repositories
{
    public class ItemRepository : IItemRepository
    {
        private readonly SportsShopContext _context;

        public ItemRepository(SportsShopContext context)
        {
            _context = context;
        }

        public async Task<List<ItemsEntity>> SearchAllItems()
        {
            var records = await _context.Items.Select(x => new ItemsEntity()
            {
                ItemNumber=x.ItemNumber,
                ItemName=x.ItemName,
                ItemValue=x.ItemValue,
                OrderNumber=x.OrderNumber

            }).ToListAsync();
            return records;

        }

        public async Task<int> CreateItem(ItemsEntity itemsEntity)
        {
            var item = new Items()
            {
                ItemName = itemsEntity.ItemName,
                ItemValue = itemsEntity.ItemValue,
                OrderNumber = itemsEntity.OrderNumber


            };
            _context.Items.Add(item);
            await _context.SaveChangesAsync();
            return item.ItemNumber;
        }

        public async Task UpdateItem(int itemNum, ItemsEntity itemsEntity)
        {
            var item = await _context.Items.FindAsync(itemNum);
            if (item != null)
            {
                item.ItemName = itemsEntity.ItemName;
                item.ItemValue = itemsEntity.ItemValue;
                item.OrderNumber = itemsEntity.OrderNumber;

                await _context.SaveChangesAsync();
            }


        }

        public async Task DeleteItem(int itemNum)
        {
            var item = new Items() { ItemNumber = itemNum };
            _context.Items.Remove(item);
            await _context.SaveChangesAsync();

        }
    }
}
