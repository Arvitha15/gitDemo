﻿using SportsShopApp.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SportsShopApp.repositories
{
    public interface IItemRepository
    {
        Task<List<ItemsEntity>> SearchAllItems();
        Task<int> CreateItem(ItemsEntity itemsEntity);
        Task UpdateItem(int itemNum, ItemsEntity itemsEntity);
        Task DeleteItem(int itemNum);
    }
}