﻿using Microsoft.EntityFrameworkCore;
using SportsShopApp.Entities;
using SportsShopApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsShopApp.repositories
{
    public class CusomerRepository: ICusomerRepository
    {
        private readonly SportsShopContext _context;

        public CusomerRepository(SportsShopContext context)
        {
            _context = context;
        }

        public async Task<List<CustomerEntity>> SearchAllCustomers()
        {
            var records = await _context.Customer.Select(x => new CustomerEntity()
            {
                CustomerNumber=x.CustomerNumber,
                CustomerName=x.CustomerName,
                CustomerAddress=x.CustomerAddress,
                ContactNumber=x.ContactNumber,
                EmailId=x.EmailId

            }).ToListAsync();
            return records;

        }

        public async Task<int> CreateCustomer(CustomerEntity customerEntity)
        {
            var customer = new Customer()
            {
                CustomerName = customerEntity.CustomerName,
                CustomerAddress = customerEntity.CustomerAddress,
                ContactNumber = customerEntity.ContactNumber,
                EmailId = customerEntity.EmailId


            };
            _context.Customer.Add(customer);
            await _context.SaveChangesAsync();
            return customer.CustomerNumber;
        }

        public async Task UpdateCusomer(int CustNum, CustomerEntity customerEntity)
        {
            var customer = await _context.Customer.FindAsync(CustNum);
            if (customer != null)
            {
                customer.CustomerName = customerEntity.CustomerName;
                customer.CustomerAddress = customerEntity.CustomerAddress;
                customer.ContactNumber = customerEntity.ContactNumber;
                customer.EmailId = customerEntity.EmailId;

                await _context.SaveChangesAsync();
            }


        }

        public async Task DeleteCustomer(int CustNo)
        {
            var customer = new Customer() { CustomerNumber = CustNo };
            _context.Customer.Remove(customer);
            await _context.SaveChangesAsync();

        }

    }
}
