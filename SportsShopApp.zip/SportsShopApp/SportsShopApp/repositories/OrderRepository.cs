﻿using Microsoft.EntityFrameworkCore;
using SportsShopApp.Entities;
using SportsShopApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportsShopApp.repositories
{
    public class OrderRepository: IOrderRepository
    {
        private readonly SportsShopContext _context;

        public OrderRepository(SportsShopContext context)
        {
            _context = context;
        }

        public async Task<List<OrdersEntity>> SearchAllOrders()
        {
            var records = await _context.Orders.Select(x => new OrdersEntity()
            {
                OrderNumber = x.OrderNumber,
                OrderDate = x.OrderDate,
                PaymentMode = x.PaymentMode,
                CustomerName = x.CustomerName

            }).ToListAsync();
            return records;

        }
        public async Task<OrdersEntity> SearchOrderByCustomerName(string custName)
        {
            var record = await _context.Orders.Where(x => x.CustomerName == custName).Select(x => new OrdersEntity()
            {
               OrderNumber=x.OrderNumber,
               OrderDate=x.OrderDate,
               PaymentMode=x.PaymentMode,
               CustomerName=x.CustomerName
               

            }).FirstOrDefaultAsync();
            return record;

        }

        public async Task<OrdersEntity> SearchOrderByOrderNum(int orderNum)
        {
            var record = await _context.Orders.Where(x => x.OrderNumber == orderNum).Select(x => new OrdersEntity()
            {
                OrderNumber = x.OrderNumber,
                OrderDate = x.OrderDate,
                PaymentMode = x.PaymentMode,
                CustomerName = x.CustomerName


            }).FirstOrDefaultAsync();
            return record;

        }

        public async Task<int> CreateOrder(OrdersEntity ordersEntity)
        {
            var order = new Orders()
            {
                OrderDate = ordersEntity.OrderDate,
                PaymentMode = ordersEntity.PaymentMode,
                CustomerName = ordersEntity.CustomerName


            };
            _context.Orders.Add(order);
            await _context.SaveChangesAsync();
            return order.OrderNumber;
        }

        public async Task UpdateOrder(int orderNum, OrdersEntity ordersEntity)
        {
            var order = await _context.Orders.FindAsync(orderNum);
            if (order != null)
            {
                order.OrderDate = ordersEntity.OrderDate;
                order.PaymentMode = ordersEntity.PaymentMode;
                order.CustomerName = ordersEntity.CustomerName;

                await _context.SaveChangesAsync();
            }


        }



    }
}
