﻿using System;
using System.Collections.Generic;

namespace SportsShopApp.Model
{
    public partial class Orders
    {
        public Orders()
        {
            Items = new HashSet<Items>();
        }

        public int OrderNumber { get; set; }
        public DateTime? OrderDate { get; set; }
        public string PaymentMode { get; set; }
        public string CustomerName { get; set; }

        public Customer CustomerNameNavigation { get; set; }
        public ICollection<Items> Items { get; set; }
    }
}
