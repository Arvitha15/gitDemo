﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace SportsShopApp.Model
{
    public partial class SportsShopContext : DbContext
    {
        public SportsShopContext()
        {
        }

        public SportsShopContext(DbContextOptions<SportsShopContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Customer> Customer { get; set; }
        public virtual DbSet<Items> Items { get; set; }
        public virtual DbSet<Orders> Orders { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=MINDDOTNET382;Database=SportsShop;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customer>(entity =>
            {
                entity.HasKey(e => e.CustomerName);

                entity.ToTable("customer");

                entity.Property(e => e.CustomerName)
                    .HasColumnName("customerName")
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.ContactNumber)
                    .HasColumnName("contactNumber")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.CustomerAddress)
                    .HasColumnName("customerAddress")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CustomerNumber)
                    .HasColumnName("customerNumber")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.EmailId)
                    .HasColumnName("emailId")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Items>(entity =>
            {
                entity.HasKey(e => e.ItemNumber);

                entity.ToTable("items");

                entity.Property(e => e.ItemNumber).HasColumnName("itemNumber");

                entity.Property(e => e.ItemName)
                    .HasColumnName("itemName")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ItemValue).HasColumnName("itemValue");

                entity.Property(e => e.OrderNumber).HasColumnName("orderNumber");

                entity.HasOne(d => d.OrderNumberNavigation)
                    .WithMany(p => p.Items)
                    .HasForeignKey(d => d.OrderNumber)
                    .HasConstraintName("FK__items__orderNumb__36B12243");
            });

            modelBuilder.Entity<Orders>(entity =>
            {
                entity.HasKey(e => e.OrderNumber);

                entity.ToTable("orders");

                entity.Property(e => e.OrderNumber).HasColumnName("orderNumber");

                entity.Property(e => e.CustomerName)
                    .HasColumnName("customerName")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.OrderDate)
                    .HasColumnName("orderDate")
                    .HasColumnType("date");

                entity.Property(e => e.PaymentMode)
                    .HasColumnName("paymentMode")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.CustomerNameNavigation)
                    .WithMany(p => p.Orders)
                    .HasForeignKey(d => d.CustomerName)
                    .HasConstraintName("FK__orders__customer__25869641");
            });
        }
    }
}
