﻿using System;
using System.Collections.Generic;

namespace SportsShopApp.Model
{
    public partial class Customer
    {
        public Customer()
        {
            Orders = new HashSet<Orders>();
        }

        public int CustomerNumber { get; set; }
        public string CustomerName { get; set; }
        public string ContactNumber { get; set; }
        public string CustomerAddress { get; set; }
        public string EmailId { get; set; }

        public ICollection<Orders> Orders { get; set; }
    }
}
