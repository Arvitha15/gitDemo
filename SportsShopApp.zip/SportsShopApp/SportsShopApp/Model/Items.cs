﻿using System;
using System.Collections.Generic;

namespace SportsShopApp.Model
{
    public partial class Items
    {
        public int ItemNumber { get; set; }
        public string ItemName { get; set; }
        public double? ItemValue { get; set; }
        public int? OrderNumber { get; set; }

        public Orders OrderNumberNavigation { get; set; }
    }
}
